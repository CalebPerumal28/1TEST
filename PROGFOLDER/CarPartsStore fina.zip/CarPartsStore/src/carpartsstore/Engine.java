/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

    public class Engine extends Product {
        Scanner kb = new Scanner(System.in);

    public Engine(CarPartsStore cps) {
        super(cps);
    }
    
    public void camshafts() {
        String [] camshaftBrands = {"Borsehung Gmbh", "FEBI-Bilstein Gmbh", "MAHLE GmbH"};
        boolean correctCam = false;
        
        while (!correctCam) {
        System.out.println("Please select camshaft brand:");
        System.out.println("1.Borsehung Gmbh\t2.FEBI-Bilstein Gmbh\t3.MAHLE GmbH");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(camshaftBrands[0]); correctCam = true; break;
                case 2:
                    brand.add(camshaftBrands[1]); correctCam = true; break;
                case 3:
                    brand.add(camshaftBrands[2]); correctCam = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void pistons() {
        String [] pistonBrands = {"AE", "Borsehung Gmbh", "MAHLE GmbH", "Nüral", "Vika"};
        boolean correctPiston = false;
        
        while (!correctPiston) {
        System.out.println("Please select piston brand:");
        System.out.println("1.AE\t2.Borsehung Gmbh\t3.MAHLE GmbH\t4.Nüral\t5.Vika");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(pistonBrands[0]); correctPiston = true; break;
                case 2:
                    brand.add(pistonBrands[1]); correctPiston = true; break;
                case 3:
                    brand.add(pistonBrands[2]); correctPiston = true; break;
                case 4:
                    brand.add(pistonBrands[3]); correctPiston = true; break;
                case 5:
                    brand.add(pistonBrands[4]); correctPiston = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void timingChain() {
        String [] TCBrands = {"FEBI-Bilstein Gmbh", "topran", "Borsehung Gmbh", "WAG"};
        boolean correctTC = false;
        
        while (!correctTC) {
        System.out.println("Please select timing chain brand:");
        System.out.println("1.FEBI-Bilstein Gmbh\t2.topran\t3.Borsehung\t4.WAG");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(TCBrands[0]); correctTC = true; break;
                case 2:
                    brand.add(TCBrands[1]); correctTC = true; break;
                case 3:
                    brand.add(TCBrands[2]); correctTC = true; break;
                case 4:
                    brand.add(TCBrands[3]); correctTC = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void engineMenu() {
        boolean engineBoolean = false;
        
        while(!engineBoolean) {
        System.out.println("Please select a category:\n"
                + "1.Camshafts\n"
                + "2.Pistons\n"
                + "3.Timing Chains");
        int engineChoice = kb.nextInt();
        
        switch(engineChoice) {
                case 1:
                    camshafts(); engineBoolean = true; break;
                case 2:
                    pistons(); engineBoolean = true; break;
                case 3:
                    timingChain(); engineBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
          }
        }
    }
