/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.Scanner;

    public class Suspension extends Product {
        Scanner kb = new Scanner(System.in);

    public Suspension(CarPartsStore cps) {
        super(cps);
    }
    
    public void shockAbsorber() {
        String [] shockAbsorberBrands = {"Bilstein Corporate", "KYB Corporation", "Monroe", "ZF SACHS", "Öhlins Racing AB"};
        boolean correctSA = false;
        
        while (!correctSA) {
        System.out.println("Please select shock absorber brand:");
        System.out.println("1.Bilstein Corporate\t2.KYB Corporation\t3.Monroe\t4.ZF SACHS\t5.Öhlins Racing AB");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(shockAbsorberBrands[0]); correctSA = true; break;
                case 2:
                    brand.add(shockAbsorberBrands[1]); correctSA = true; break;
                case 3:
                    brand.add(shockAbsorberBrands[2]); correctSA = true; break;
                case 4:
                    brand.add(shockAbsorberBrands[3]); correctSA = true; break;
                case 5:
                    brand.add(shockAbsorberBrands[4]); correctSA = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void coilovers() {
        String [] coiloverBrands = {"BC Racing", "Bilstein Corporate", "Eibach GmbH", "H&R", "KW Suspensions, Inc.", "Öhlins Racing AB"};
        
        boolean correctCoil = false;
        
        while (!correctCoil) {
        System.out.println("Please select coilover brand:"
                + "1.BC Racing\t2.Bilstein Corporate\t3.Eibach GmbH\t4.H&R\t5.KW Suspension, Inc.\t6.Öhlins Racing AB");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(coiloverBrands[0]); correctCoil = true; break;
                case 2:
                    brand.add(coiloverBrands[1]); correctCoil = true; break;
                case 3:
                    brand.add(coiloverBrands[2]); correctCoil = true; break;
                case 4:
                    brand.add(coiloverBrands[3]); correctCoil = true; break;
                case 5:
                    brand.add(coiloverBrands[4]); correctCoil = true; break;
                case 6:
                    brand.add(coiloverBrands[5]); correctCoil = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();
        cps.menuOne();
    }
    
    public void suspensionMenu() {
        boolean susBoolean = false;
        
        while(!susBoolean) {
        System.out.println("Please select a category:\n"
                + "1.Shock Absorbers\n"
                + "2.Coilovers");
        int susChoice = kb.nextInt();
        
        switch(susChoice) {
                case 1:
                    shockAbsorber(); susBoolean = true; break;
                case 2:
                    coilovers(); susBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
          }
        }
    }
