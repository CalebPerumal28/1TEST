/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ishka
 */
public class Product {
    Scanner kb = new Scanner(System.in);
    
    public final ArrayList<String> brand = new ArrayList<>();
    public final ArrayList<Double> price = new ArrayList<>();
    public final ArrayList<Integer> quantity = new ArrayList<>();
    public final ArrayList<String> manufacturer = new ArrayList<>();
    public final ArrayList<String> model = new ArrayList<>();
    public final ArrayList<String> description = new ArrayList<>();
    public final ArrayList<String> code = new ArrayList<>();
    final CarPartsStore cps;
    
    public Product(CarPartsStore cps) {
        this.cps = cps;
    }
    
    public void generalPart() {
        System.out.println("Enter product price:");
        double prdctPrice = kb.nextDouble();
        price.add(prdctPrice);

        System.out.println("Enter product quantity:");
        int prdctQuantity = kb.nextInt();
        quantity.add(prdctQuantity);

        System.out.println("Enter vehicle manufacturer:");
        String prdctManufacturer = kb.next();
        manufacturer.add(prdctManufacturer);

        System.out.println("Enter vehicle model:");
        String manuModel = kb.next();
        model.add(manuModel);

        System.out.println("Enter product description:");
        String prdctDesc = kb.next();
        description.add(prdctDesc);

        boolean codeChar = false;
        while (!codeChar) {
            System.out.println("Code must be 8 characters or less.\n"
                + "Enter product code:");
            String prdctCode = kb.next();

            if (prdctCode.length() > 0 && prdctCode.length() <= 8) {
                String codeTwo = prdctManufacturer.substring(0, 2).toUpperCase();
                prdctCode = codeTwo + prdctCode;
                System.out.println("The product code is: " + prdctCode);
                code.add(prdctCode);
                System.out.println(code);
                codeChar = true;
            } else if (prdctCode.length() <= 0) {
                System.out.println("You have not entered a code. Please try again...");
            } else if (prdctCode.length() > 8) {
                System.out.println("Your code is too long. Please try again...");
            }
        }
    }
    
    public void searchPart() {
        System.out.println("Please enter the part code:");
        String searchQuery = kb.next();
        
        if (code.isEmpty()) {
        System.out.println("Database is empty. Please add parts to the inventory first...");
        cps.menuOne();
        }

        boolean found = false; 
        boolean cancel = false;
        boolean correctOption = false;

        for (int i = 0; i < code.size(); i++) {
            if (code.get(i).equals(searchQuery)) {
                while(!correctOption) {
                    System.out.println("\nPART " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "Brand: " + brand.get(i) + "\n"
                    + "Price: " + price.get(i) + "\n" 
                    + "Quantity: " + quantity.get(i) + "\n"
                    + "Manufacturer: " + manufacturer.get(i) + "\n"
                    + "Model: " + model.get(i) + "\n"
                    + "Description: " + description.get(i) + "\n"
                    + "Part Code: " + code.get(i));
                
                System.out.println("Do you wish to delete part " + code.get(i) + " and all its associated information from the system? Yes (y) to delete or No (n) to cancel.");
                String deleteConfirmation = kb.next();
                switch (deleteConfirmation.toLowerCase()) {
                    case "y" ->
                    {
                        brand.remove(i);
                        price.remove(i);
                        manufacturer.remove(i);
                        model.remove(i);
                        description.remove(i);
                        code.remove(i);
                        found = true; // Set the flag to true
                        correctOption = true;
                        break;
                    }
                    case "n" ->
                    {
                        cancel = true;
                        correctOption = true;
                        cps.menuOne();
                        break;
                    }
                    default -> System.out.println("Please enter only one of the following options: \"y\" or \"n\": ");
                }
             }
          }
       }
        
        if (found) {
            System.out.println("The part details have been deleted successfully.");
        } else if (cancel) {
            System.out.println("Deletion aborted...");
        }
        else {
            System.out.println("Part code: " + searchQuery + " not found.");
        }
        
        cps.menuOne();
    }
    
    public void displayParts() {
        if (code.isEmpty()) {
        System.out.println("Database is empty. Please add parts to the inventory first...");
        cps.menuOne();
        }
        
        for (int i = 0; i < code.size(); i++)
        {
            System.out.println("\nPART " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "Brand: " + brand.get(i) + "\n"
                    + "Price: " + price.get(i) + "\n" 
                    + "Quantity: " + quantity.get(i) + "\n"
                    + "Manufacturer: " + manufacturer.get(i) + "\n"
                    + "Model: " + model.get(i) + "\n"
                    + "Description: " + description.get(i) + "\n"
                    + "Part Code: " + code.get(i));
        }
        cps.menuOne();
    }
    
}

